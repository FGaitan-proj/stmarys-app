//
//  Constants.swift
//  TypesofQuestions
//
//  Created by Fernando Gaitan on 7/18/20.
//  Copyright © 2020 Fernando Gaitan & Rachel Morrow. All rights reserved.
//

import Foundation

struct Constants {
    
    struct Storyboard{
        
        static let MainMenuController = "MainMenu"
    }
}
